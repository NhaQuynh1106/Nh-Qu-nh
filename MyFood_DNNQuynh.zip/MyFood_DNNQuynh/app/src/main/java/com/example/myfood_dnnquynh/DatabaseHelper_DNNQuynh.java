package com.example.myfood_dnnquynh;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper_DNNQuynh extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Food_DNNQuynh";
    public static final int DATABASE_VERSION = 1;

    public DatabaseHelper_DNNQuynh(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Tạo bảng User
        db.execSQL("CREATE TABLE User_DNNQuynh (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "password TEXT)");

        // Tạo bảng Restaurant
        db.execSQL("CREATE TABLE Restaurant_DNNQuynh (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "address TEXT, " +
                "image TEXT)");

        // Tạo bảng Food
        db.execSQL("CREATE TABLE Food_DNNQuynh (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "price REAL, " +
                "description TEXT, " +
                "size TEXT, " +
                "image TEXT, " +
                "restaurantId INTEGER, " +
                "FOREIGN KEY (restaurantId) REFERENCES Restaurant_DNNQuynh(id))");

        // Thêm dữ liệu User
        db.execSQL("INSERT INTO User_DNNQuynh (username, password) VALUES " +
                "('quynh1', '123'), ('quynh2', '234'), ('quynh3', '345'), ('quynh4', '456'), ('quynh5', '567')");

        // Thêm dữ liệu Restaurant
        db.execSQL("INSERT INTO Restaurant_DNNQuynh (name, address, image) VALUES " +
                "('Quán Ăn Gấu', '123 Đường Trúc Xanh', 'img1.png')," +
                "('Quán Mì Trứng', '456 Đường Lá Bàng', 'img2.png')," +
                "('Lẩu Panda', '789 Đường Gấu Trúc', 'img3.png')," +
                "('Bún Mắm Mẹ Nấu', '101 Đường Quê', 'img4.png')," +
                "('Cháo Gà Công Nghiệp', '202 Đường Nông Trại', 'img5.png')");

        // Thêm dữ liệu Food
        db.execSQL("INSERT INTO Food_DNNQuynh (name, price, description, size, image, restaurantId) VALUES " +
                "('Cơm Gà', 25000, 'Ngon bổ rẻ', 'small', 'img1.png', 1)," +
                "('Phở Bò', 30000, 'Truyền thống', 'medium', 'img2.png', 1)," +
                "('Bánh Mì', 15000, 'Nóng giòn', 'small', 'img3.png', 2)," +
                "('Mì Quảng', 27000, 'Đậm đà', 'large', 'img4.png', 2)," +
                "('Gỏi Cuốn', 10000, 'Thanh mát', 'small', 'img5.png', 3)," +
                "('Bún Bò', 28000, 'Huế chính hiệu', 'medium', 'img6.png', 3)," +
                "('Lẩu Thái', 50000, 'Chua cay', 'large', 'img7.png', 4)," +
                "('Súp Cua', 20000, 'Bổ dưỡng', 'small', 'img8.png', 4)," +
                "('Bánh Canh', 25000, 'Đặc sản', 'medium', 'img9.png', 5)," +
                "('Cháo Gà', 22000, 'Ấm bụng', 'small', 'img10.png', 5)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS User_DNNQuynh");
        db.execSQL("DROP TABLE IF EXISTS Restaurant_DNNQuynh");
        db.execSQL("DROP TABLE IF EXISTS Food_DNNQuynh");
        onCreate(db);
    }
}
