package com.example.myfood_dnnquynh;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity_DNNQuynh extends AppCompatActivity {

    EditText editUsername, editPassword, editRePassword;
    Button btnRegister;
    DatabaseHelper_DNNQuynh dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_dnnquynh);

        editUsername = findViewById(R.id.editUsernameReg_DNNQuynh);
        editPassword = findViewById(R.id.editPasswordReg_DNNQuynh);
        editRePassword = findViewById(R.id.editRePasswordReg_DNNQuynh);
        btnRegister = findViewById(R.id.btnRegister_DNNQuynh);

        dbHelper = new DatabaseHelper_DNNQuynh(this);

        btnRegister.setOnClickListener(v -> checkRegister_DNNQuynh());
    }

    private void checkRegister_DNNQuynh() {
        String user = editUsername.getText().toString();
        String pass = editPassword.getText().toString();
        String rePass = editRePassword.getText().toString();

        if (!pass.equals(rePass)) {
            Toast.makeText(this, "Mật khẩu không khớp!", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", user);
        values.put("password", pass);

        long result = db.insert("User_DNNQuynh", null, values);
        if (result != -1) {
            Toast.makeText(this, "Đăng ký thành công!", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity_DNNQuynh.class));
        } else {
            Toast.makeText(this, "Thất bại!", Toast.LENGTH_SHORT).show();
        }
    }
}
