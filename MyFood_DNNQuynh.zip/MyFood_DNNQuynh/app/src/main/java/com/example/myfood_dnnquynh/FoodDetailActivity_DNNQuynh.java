package com.example.myfood_dnnquynh;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class FoodDetailActivity_DNNQuynh extends AppCompatActivity {

    TextView tvName, tvDescription, tvPrice;
    Spinner spinnerSize;
    Button btnAddToCart;
    DatabaseHelper_DNNQuynh dbHelper;

    String selectedSize = "small";
    double basePrice = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_detail);

        tvName = findViewById(R.id.tvFoodName_DNNQuynh);
        tvDescription = findViewById(R.id.tvDescription_DNNQuynh);
        tvPrice = findViewById(R.id.tvPrice_DNNQuynh);
        spinnerSize = findViewById(R.id.spinnerSize_DNNQuynh);
        btnAddToCart = findViewById(R.id.btnAddToCart_DNNQuynh);
        dbHelper = new DatabaseHelper_DNNQuynh(this);

        int foodId = getIntent().getIntExtra("foodId", -1);
        loadFoodDetail(foodId);
        setupSpinner();
        handleAddToCart();
    }

    private void loadFoodDetail(int foodId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT name, description, price, size FROM Food_DNNQuynh WHERE id = ?",
                new String[]{String.valueOf(foodId)});

        if (cursor.moveToFirst()) {
            String name = cursor.getString(0);
            String description = cursor.getString(1);
            basePrice = cursor.getDouble(2);
            selectedSize = cursor.getString(3); // default

            tvName.setText(name);
            tvDescription.setText(description);
            updatePrice(selectedSize);
        }
        cursor.close();
    }

    private void setupSpinner() {
        String[] sizes = {"small", "medium", "large"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sizes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSize.setAdapter(adapter);

        // Gán size mặc định
        int defaultIndex = 0;
        if (selectedSize.equals("medium")) defaultIndex = 1;
        else if (selectedSize.equals("large")) defaultIndex = 2;
        spinnerSize.setSelection(defaultIndex);

        spinnerSize.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                selectedSize = sizes[position];
                updatePrice(selectedSize);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    private void updatePrice(String size) {
        double multiplier = 1.0;
        if (size.equals("medium")) multiplier = 1.2;
        else if (size.equals("large")) multiplier = 1.5;
        double finalPrice = basePrice * multiplier;
        tvPrice.setText("Giá: " + (int) finalPrice + " đ");
    }

    private void handleAddToCart() {
        btnAddToCart.setOnClickListener(v -> {
            Toast.makeText(this, "Đã thêm vào giỏ hàng!", Toast.LENGTH_SHORT).show();
            // Có thể lưu vào DB hoặc ArrayList sau nếu cần
        });
    }
}
