package com.example.myfood_dnnquynh;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FoodListActivity_DNNQuynh extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<FoodModel> foodList = new ArrayList<>();
    FoodAdapter adapter;
    DatabaseHelper_DNNQuynh dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list_dnnquynh);

        recyclerView = findViewById(R.id.recyclerFood_DNNQuynh);
        dbHelper = new DatabaseHelper_DNNQuynh(this);

        int resId = getIntent().getIntExtra("restaurantId", -1);
        loadFoods(resId);
    }

    private void loadFoods(int resId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Food_DNNQuynh WHERE restaurantId = ?", new String[]{String.valueOf(resId)});

        foodList.clear();
        while (cursor.moveToNext()) {
            foodList.add(new FoodModel(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getDouble(2),
                    cursor.getString(3),
                    cursor.getString(4),
                    cursor.getString(5),
                    cursor.getInt(6)
            ));
        }
        cursor.close();

        adapter = new FoodAdapter(this, foodList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}
