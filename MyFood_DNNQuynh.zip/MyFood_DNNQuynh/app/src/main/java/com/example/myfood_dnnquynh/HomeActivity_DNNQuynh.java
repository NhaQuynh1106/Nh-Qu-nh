package com.example.myfood_dnnquynh;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeActivity_DNNQuynh extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<RestaurantModel> list = new ArrayList<>();
    RestaurantAdapter adapter;
    DatabaseHelper_DNNQuynh dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_dnnquynh);

        recyclerView = findViewById(R.id.recyclerRestaurant_DNNQuynh);
        dbHelper = new DatabaseHelper_DNNQuynh(this);

        loadRestaurants();
    }

    private void loadRestaurants() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Restaurant_DNNQuynh", null);

        list.clear();
        while (cursor.moveToNext()) {
            list.add(new RestaurantModel(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3)
            ));
        }
        cursor.close();

        adapter = new RestaurantAdapter(this, list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}
