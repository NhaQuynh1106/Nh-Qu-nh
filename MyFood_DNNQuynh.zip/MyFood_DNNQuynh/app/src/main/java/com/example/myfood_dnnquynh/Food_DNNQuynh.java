package com.example.myfood_dnnquynh;

public class Food_DNNQuynh {
    public String name, size, description, image;
    public double price;

    public Food_DNNQuynh(String name, double price, String size, String description, String image) {
        this.name = name;
        this.price = price;
        this.size = size;
        this.description = description;
        this.image = image;
    }
}