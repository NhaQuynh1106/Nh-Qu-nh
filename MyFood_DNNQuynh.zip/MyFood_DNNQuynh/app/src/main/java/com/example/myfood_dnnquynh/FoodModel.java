package com.example.myfood_dnnquynh;

public class FoodModel {
    public int id;
    public String name;
    public double price;
    public String description;
    public String size;
    public String image;
    public int restaurantId;

    public FoodModel(int id, String name, double price, String description, String size, String image, int restaurantId) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.size = size;
        this.image = image;
        this.restaurantId = restaurantId;
    }
}
