package com.example.myfood_dnnquynh;

public class RestaurantModel {
    public int id;
    public String name;
    public String address;
    public String image;

    public RestaurantModel(int id, String name, String address, String image) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.image = image;
    }
}
